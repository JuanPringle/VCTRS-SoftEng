public class User {
	protected int id;
	
	public User(int id) {
		this.id=id;
	}
	public int getID() {
		return id;
	}
}