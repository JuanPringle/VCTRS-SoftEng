
import java.io.FileNotFoundException;


public class VehicularRunner {

	public static void main(String[] args) throws FileNotFoundException {
		new GUI();
		
	}
}